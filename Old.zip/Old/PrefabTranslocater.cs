using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;
using System;
using static Unity.VisualScripting.Metadata;
using static UnityEditor.Experimental.AssetDatabaseExperimental.AssetDatabaseCounters;
using static UnityEditor.Progress;
 
public class PrefabTranslocater : MonoBehaviour
{
    public enum SearchModeEnum{PrefabSearch,TextSearch};
    public SearchModeEnum searchMode = SearchModeEnum.PrefabSearch;

    [SerializeField] GameObject parentGameObject;
    [SerializeField] GameObject prefab;
    [SerializeField] string searchName;

    public List<GameObject> objectsToTransfer = new List<GameObject>();
    GameObject[] allObjects;
      
    [SerializeField] GameObject targetObject;
    [SerializeField] GameObject replacePrefab;
    public bool replace;

    [SerializeField] string helpText;

    public event Action SelectedObjectClearEvent;

    public void FindObjects()
    {
        helpText = @"";
        objectsToTransfer.Clear();

        if (searchMode == SearchModeEnum.PrefabSearch)
        {
            if(prefab != null)
            {
                allObjects = PrefabUtility.FindAllInstancesOfPrefab(prefab);

                if (parentGameObject == null)
                {
                    foreach (GameObject obj in allObjects)
                    {
                        objectsToTransfer.Add(obj);
                    }
                }
                else
                {
                    foreach (GameObject obj in allObjects)
                    {
                        if (obj.transform.IsChildOf(parentGameObject.transform))
                        {
                            objectsToTransfer.Add(obj);
                        }
                    }
                }
            }
            else
            {
                helpText = @"Please add a prefab to search for!";
            }
        }
        else 
        {
            if(searchName != null)
            {
                allObjects = FindObjectsOfType<GameObject>();

                if (parentGameObject == null)
                {
                    foreach (GameObject obj in allObjects)
                    {
                        if (obj.name.Contains(searchName))
                        {
                            objectsToTransfer.Add(obj);
                        }
                    }
                } 
                else
                {
                    foreach (GameObject obj in allObjects)
                    {
                        if (obj.transform.IsChildOf(parentGameObject.transform))
                        {
                            if (obj.name.Contains(searchName))
                            {
                                objectsToTransfer.Add(obj);
                            }
                        }
                    }
                }
            }
            else
            {
                helpText = @"Please input text into the text field.";
            }
        }
    }

    public void TransLocate()
    {
        if(objectsToTransfer.Count > 0)
        {
            if (targetObject != null)
            {
                if (!replace)
                {
                    foreach (GameObject obj in objectsToTransfer)
                    {
                        obj.transform.parent = targetObject.transform;
                    }
                    objectsToTransfer.Clear();
                    SelectedObjectClearEvent?.Invoke();
                }
                else if (replacePrefab != null && replace)
                {
                    int count = objectsToTransfer.Count;
                    for (int i = 0; i < count; i++)
                    {
                        GameObject obj = objectsToTransfer[0];

                        GameObject temp = Instantiate(replacePrefab);
                        temp.transform.parent = targetObject.transform;
                        temp.transform.position = obj.transform.position;
                        temp.transform.rotation = obj.transform.rotation;
                        temp.transform.localScale = obj.transform.localScale;
                        DestroyImmediate(obj);

                        objectsToTransfer.Remove(obj);
                    }
                    SelectedObjectClearEvent?.Invoke();
                }
                else if (replacePrefab == null && replace)
                {
                    helpText = @"Please input a replacement prefab or disable replace";
                }
            }
            else
            {
                if (!replace)
                {
                    helpText = "Please select a target object";
                }
                else
                {
                    int count = objectsToTransfer.Count;
                    for (int i = 0; i < count; i++)
                    {
                        GameObject obj = objectsToTransfer[0];
                        GameObject temp = Instantiate(replacePrefab);
                        if (obj.transform.parent != null)
                        {
                            temp.transform.parent = obj.transform.parent.gameObject.transform;
                        }
                        temp.transform.position = obj.transform.position;
                        temp.transform.rotation = obj.transform.rotation;
                        temp.transform.localScale = obj.transform.localScale;
                        DestroyImmediate(obj);
                        objectsToTransfer.Remove(obj);
                    }
                    SelectedObjectClearEvent?.Invoke();
                }
            }
        }
        else
        {
            helpText = "Please search for some objects first";
        }

    }
}      
                                          